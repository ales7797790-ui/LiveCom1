package com.livecom.app.data.repository

import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.tasks.await

class AuthRepository(
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
) {
    val currentUid: String? get() = auth.currentUser?.uid

    /** يعيد uid الحالي إن وُجد، وإلا يسجّل دخولاً مجهولاً. */
    suspend fun signInAnonymously(): Result<String> = try {
        val user = auth.currentUser ?: auth.signInAnonymously().await().user
        if (user != null) Result.success(user.uid)
        else Result.failure(IllegalStateException("User is null"))
    } catch (e: Exception) {
        Result.failure(e)
    }
}
