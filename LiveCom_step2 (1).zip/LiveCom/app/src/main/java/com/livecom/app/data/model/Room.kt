package com.livecom.app.data.model

data class Room(
    val id: String = "",
    val title: String = "",
    val description: String = "",
    val ownerId: String = "",
    val isPrivate: Boolean = false,
    val isActive: Boolean = true,
    val participantCount: Long = 0,
    val createdAtMillis: Long = 0
)
