package com.livecom.app.ui.rooms

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.livecom.app.data.model.Room
import com.livecom.app.databinding.ItemRoomBinding

class RoomsAdapter(
    private val onClick: (Room) -> Unit
) : ListAdapter<Room, RoomsAdapter.VH>(Diff) {

    inner class VH(val b: ItemRoomBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemRoomBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val room = getItem(position)
        with(holder.b) {
            tvTitle.text = room.title
            tvDescription.text = room.description
            tvDescription.visibility = if (room.description.isBlank()) View.GONE else View.VISIBLE
            tvCount.text = "👥 ${room.participantCount}"
            tvPrivate.visibility = if (room.isPrivate) View.VISIBLE else View.GONE
            root.setOnClickListener { onClick(room) }
        }
    }

    object Diff : DiffUtil.ItemCallback<Room>() {
        override fun areItemsTheSame(a: Room, b: Room) = a.id == b.id
        override fun areContentsTheSame(a: Room, b: Room) = a == b
    }
}
