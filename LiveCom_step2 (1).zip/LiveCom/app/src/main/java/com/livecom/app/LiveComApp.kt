package com.livecom.app

import android.app.Application

class LiveComApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // هنا لاحقاً: تهيئة ZEGO وأي خدمات عامة
    }
}
