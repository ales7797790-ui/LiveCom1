package com.livecom.app.ui.rooms

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import com.livecom.app.core.UiState
import com.livecom.app.databinding.ActivityRoomsBinding
import kotlinx.coroutines.launch

class RoomsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRoomsBinding
    private val viewModel: RoomsViewModel by viewModels()

    private val adapter = RoomsAdapter { room ->
        // الخطوة 4: فتح غرفة البث. حالياً رسالة فقط.
        Toast.makeText(this, room.title, Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRoomsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.rvRooms.layoutManager = LinearLayoutManager(this)
        binding.rvRooms.adapter = adapter
        binding.fabAdd.setOnClickListener { viewModel.addTestRoom() } // مؤقت

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.state.collect { render(it) }
            }
        }
    }

    private fun render(state: UiState<List<com.livecom.app.data.model.Room>>) {
        binding.progress.visibility = if (state is UiState.Loading) View.VISIBLE else View.GONE
        when (state) {
            is UiState.Loading -> binding.tvEmpty.visibility = View.GONE
            is UiState.Success -> {
                adapter.submitList(state.data)
                binding.tvEmpty.visibility = if (state.data.isEmpty()) View.VISIBLE else View.GONE
            }
            is UiState.Error -> {
                binding.tvEmpty.visibility = View.GONE
                Toast.makeText(this, state.message, Toast.LENGTH_LONG).show()
            }
        }
    }
}
