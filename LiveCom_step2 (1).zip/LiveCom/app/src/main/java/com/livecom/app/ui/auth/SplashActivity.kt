package com.livecom.app.ui.auth

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.livecom.app.R
import com.livecom.app.data.repository.AuthRepository
import com.livecom.app.ui.rooms.RoomsActivity
import kotlinx.coroutines.launch

class SplashActivity : AppCompatActivity() {

    private val authRepo = AuthRepository()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        lifecycleScope.launch {
            authRepo.signInAnonymously()
                .onSuccess {
                    startActivity(Intent(this@SplashActivity, RoomsActivity::class.java))
                    finish()
                }
                .onFailure {
                    Toast.makeText(this@SplashActivity, R.string.sign_in_failed, Toast.LENGTH_LONG).show()
                }
        }
    }
}
