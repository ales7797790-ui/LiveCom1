package com.livecom.app.data.repository

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.livecom.app.data.model.Room
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

class RoomRepository(
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance()
) {
    private val rooms get() = db.collection("rooms")

    /** الغرف النشطة فقط، بتحديث لحظي. الترتيب يتم محلياً لتجنب الحاجة لفهرس مركّب. */
    fun observeActiveRooms(): Flow<Result<List<Room>>> = callbackFlow {
        val reg = rooms.whereEqualTo("isActive", true)
            .addSnapshotListener { snap, err ->
                if (err != null) {
                    trySend(Result.failure(err))
                    return@addSnapshotListener
                }
                val list = snap?.documents.orEmpty()
                    .map { it.toRoom() }
                    .sortedByDescending { it.createdAtMillis }
                trySend(Result.success(list))
            }
        awaitClose { reg.remove() }
    }

    /** مؤقت للاختبار فقط: ينشئ غرفة تجريبية. سيُستبدل بشاشة إنشاء الغرفة في الخطوة 3. */
    suspend fun createTestRoom(ownerId: String): Result<Unit> = try {
        val n = (1..999).random()
        rooms.add(
            mapOf(
                "title" to "غرفة تجريبية $n",
                "description" to "وصف تجريبي",
                "ownerId" to ownerId,
                "isPrivate" to false,
                "isActive" to true,
                "participantCount" to 0L,
                "createdAt" to Timestamp.now()
            )
        ).await()
        Result.success(Unit)
    } catch (e: Exception) {
        Result.failure(e)
    }

    private fun DocumentSnapshot.toRoom() = Room(
        id = id,
        title = getString("title").orEmpty(),
        description = getString("description").orEmpty(),
        ownerId = getString("ownerId").orEmpty(),
        isPrivate = getBoolean("isPrivate") ?: false,
        isActive = getBoolean("isActive") ?: true,
        participantCount = getLong("participantCount") ?: 0L,
        createdAtMillis = getTimestamp("createdAt")?.toDate()?.time ?: 0L
    )
}
