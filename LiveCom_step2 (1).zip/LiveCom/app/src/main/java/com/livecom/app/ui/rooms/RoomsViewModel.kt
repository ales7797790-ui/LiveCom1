package com.livecom.app.ui.rooms

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.livecom.app.core.UiState
import com.livecom.app.data.model.Room
import com.livecom.app.data.repository.AuthRepository
import com.livecom.app.data.repository.RoomRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class RoomsViewModel(
    private val roomRepo: RoomRepository = RoomRepository(),
    private val authRepo: AuthRepository = AuthRepository()
) : ViewModel() {

    private val _state = MutableStateFlow<UiState<List<Room>>>(UiState.Loading)
    val state: StateFlow<UiState<List<Room>>> = _state

    init {
        viewModelScope.launch {
            roomRepo.observeActiveRooms().collect { result ->
                _state.value = result.fold(
                    onSuccess = { UiState.Success(it) },
                    onFailure = { UiState.Error(it.message ?: "خطأ غير معروف") }
                )
            }
        }
    }

    fun addTestRoom() {
        val uid = authRepo.currentUid ?: return
        viewModelScope.launch { roomRepo.createTestRoom(uid) }
    }
}
