# LiveCom — الخطوة 1

## التشغيل
1. افتح Android Studio ← File ▸ Open ← اختر مجلد LiveCom وانتظر Gradle Sync.
2. في Firebase Console: أنشئ مشروعاً وأضف تطبيق أندرويد باسم الحزمة `com.livecom.app`.
3. نزّل `google-services.json` وضعه داخل مجلد `app/` (بجانب app/build.gradle.kts).
4. فعّل Authentication ▸ Sign-in method ▸ Anonymous.
5. شغّل التطبيق: ستظهر شاشة الغرف مع UID الخاص بك.

## ملاحظات
- المشروع مضبوط على AGP 7.4.2 و Gradle 7.5 و JDK 17 (مدمج في Android Studio 2022).
- إن ظهر تنبيه عن Gradle JDK: Settings ▸ Build Tools ▸ Gradle ▸ Gradle JDK ← اختر JetBrains Runtime 17.

## الخطوة 2: قائمة الغرف النشطة
- في Firebase: أنشئ قاعدة Firestore بوضع الاختبار (Test mode) مؤقتاً. قواعد الأمان الحقيقية في الخطوة 8.
- شغّل التطبيق واضغط زر + لإضافة غرفة تجريبية، وستظهر فوراً كبطاقة دون إعادة تحميل.
- افتح Firestore Console وغيّر isActive إلى false في أي غرفة، وستختفي لحظياً من القائمة.
